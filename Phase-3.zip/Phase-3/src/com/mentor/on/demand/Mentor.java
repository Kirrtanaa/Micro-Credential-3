package com.mentor.on.demand;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mentor extends User {

	@Id
	private Long mentorId;

	private String mentorName;

	public Mentor() {
		super();
	}

	public Mentor(Long mentorId, String mentorName) {
		super();
		this.mentorId = mentorId;
		this.mentorName = mentorName;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public String getMentorName() {
		return mentorName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

}